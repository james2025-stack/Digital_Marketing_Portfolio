James Githae Masaulu - portfolio website

Files
  index.html   the website
  assets/      photo, CV (PDF), video, images and the company profile

To put it on GitHub Pages
  1. Create a new repository on GitHub (for example "digital-marketing-portfolio") and keep it Public.
  2. Upload index.html and the whole assets folder to the main branch of the repository.
  3. In the repository, open Settings, then Pages. Under Build and deployment choose "Deploy from a branch", pick the main branch and the / (root) folder, then Save.
  4. After a minute or two your site is live at https://james2025-stack.github.io/<repository-name>/

Keep the folder structure exactly as it is: index.html must sit next to the assets folder.
To replace your CV later, upload a new PDF to assets with the same file name.
